import tkinter as tk

# Window setup
WIDTH, HEIGHT = 800, 600
PADDLE_WIDTH, PADDLE_HEIGHT = 15, 100
BALL_SIZE = 20
PADDLE_SPEED = 10

# Initialize main window
root = tk.Tk()
root.title("Pong in Tkinter")

canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT, bg="black")
canvas.pack()

# Scores
left_score, right_score = 0, 0
score_display = canvas.create_text(
    WIDTH // 2, 30,
    text="0    0",
    fill="white",
    font=("Courier", 40),
    state="hidden"  # hidden until game starts
)

# Start screen (bigger circle + smaller bold text)
circle_radius = 140
start_circle = canvas.create_oval(
    WIDTH // 2 - circle_radius, HEIGHT // 2 - circle_radius,
    WIDTH // 2 + circle_radius, HEIGHT // 2 + circle_radius,
    fill="white"
)
start_text = canvas.create_text(
    WIDTH // 2, HEIGHT // 2,
    text="Press Enter to start",
    fill="black",
    font=("Courier", 14, "bold")  # smaller + bold so it fits inside circle
)

# Paddles and ball (hidden initially)
left_paddle = canvas.create_rectangle(
    50, HEIGHT // 2 - PADDLE_HEIGHT // 2,
    50 + PADDLE_WIDTH, HEIGHT // 2 + PADDLE_HEIGHT // 2,
    fill="white",
    state="hidden"
)
right_paddle = canvas.create_rectangle(
    WIDTH - 50 - PADDLE_WIDTH, HEIGHT // 2 - PADDLE_HEIGHT // 2,
    WIDTH - 50, HEIGHT // 2 + PADDLE_HEIGHT // 2,
    fill="white",
    state="hidden"
)
ball = canvas.create_oval(
    WIDTH // 2 - BALL_SIZE // 2, HEIGHT // 2 - BALL_SIZE // 2,
    WIDTH // 2 + BALL_SIZE // 2, HEIGHT // 2 + BALL_SIZE // 2,
    fill="white",
    state="hidden"
)

# Ball movement vars
ball_dx, ball_dy = 5, 5
ball_speed = 1.0
hit_count = 0   # counts paddle hits
game_running = False  # game starts only after Enter

# Paddle movement state
left_move = 0
right_move = 0


def key_press(event):
    global left_move, right_move, game_running
    if event.keysym == "w":
        left_move = -PADDLE_SPEED
    elif event.keysym == "s":
        left_move = PADDLE_SPEED
    elif event.keysym == "Up":
        right_move = -PADDLE_SPEED
    elif event.keysym == "Down":
        right_move = PADDLE_SPEED
    elif event.keysym == "Escape":
        root.destroy()  # Quit game
    elif event.keysym == "Return" and not game_running:
        start_game()


def key_release(event):
    global left_move, right_move
    if event.keysym in ("w", "s"):
        left_move = 0
    elif event.keysym in ("Up", "Down"):
        right_move = 0


def reset_ball(direction):
    """Reset ball to center, keep paddles where they are, keep game running"""
    global ball_dx, ball_dy, ball_speed, hit_count
    canvas.coords(
        ball,
        WIDTH // 2 - BALL_SIZE // 2, HEIGHT // 2 - BALL_SIZE // 2,
        WIDTH // 2 + BALL_SIZE // 2, HEIGHT // 2 + BALL_SIZE // 2
    )
    ball_dx = 5 * direction
    ball_dy = 5
    ball_speed = 1.0
    hit_count = 0


def start_game():
    global game_running
    game_running = True
    # Remove start screen
    canvas.delete(start_circle)
    canvas.delete(start_text)
    # Show paddles, ball, and score
    canvas.itemconfig(left_paddle, state="normal")
    canvas.itemconfig(right_paddle, state="normal")
    canvas.itemconfig(ball, state="normal")
    canvas.itemconfig(score_display, state="normal")
    reset_ball(1)
    game_loop()


def game_loop():
    global ball_dx, ball_dy, left_score, right_score, ball_speed, hit_count

    if not game_running:
        return

    # Move paddles smoothly
    lp_coords = canvas.coords(left_paddle)
    rp_coords = canvas.coords(right_paddle)

    if left_move != 0:
        if lp_coords[1] + left_move >= 0 and lp_coords[3] + left_move <= HEIGHT:
            canvas.move(left_paddle, 0, left_move)

    if right_move != 0:
        if rp_coords[1] + right_move >= 0 and rp_coords[3] + right_move <= HEIGHT:
            canvas.move(right_paddle, 0, right_move)

    # Move ball
    canvas.move(ball, ball_dx * ball_speed, ball_dy * ball_speed)
    ball_coords = canvas.coords(ball)

    # Bounce top/bottom
    if ball_coords[1] <= 0 or ball_coords[3] >= HEIGHT:
        ball_dy *= -1

    # Bounce off paddles + speed up every 2 hits
    if (ball_coords[0] <= lp_coords[2] and lp_coords[1] < ball_coords[3] and lp_coords[3] > ball_coords[1]) \
            or (ball_coords[2] >= rp_coords[0] and rp_coords[1] < ball_coords[3] and rp_coords[3] > ball_coords[1]):
        ball_dx *= -1
        hit_count += 1
        ball_speed = 1.0 + (hit_count // 2) * 0.15  # +0.15 every 2 hits

    # Score + instant reset
    if ball_coords[0] <= 0:
        right_score += 1
        canvas.itemconfig(score_display, text=f"{left_score}    {right_score}")
        reset_ball(1)

    elif ball_coords[2] >= WIDTH:
        left_score += 1
        canvas.itemconfig(score_display, text=f"{left_score}    {right_score}")
        reset_ball(-1)

    root.after(20, game_loop)


# Bindings
root.bind("<KeyPress>", key_press)
root.bind("<KeyRelease>", key_release)

# Idle loop (waiting for Enter)
root.mainloop()
