import tkinter as tk
import random

# Game settings
COLS, ROWS, CELL = 10, 20, 30
W, H = COLS * CELL, ROWS * CELL
BG = "#0f1115"
GRID = "#1e2229"
COLORS = {
    "I": "#5bc0eb", "O": "#fde74c", "T": "#9b5de5",
    "S": "#00f5d4", "Z": "#ff5a5f", "J": "#00a6fb", "L": "#ffb703"
}

# Tetromino shapes (rotations)
SHAPES = {
    "I": [[(0,1),(1,1),(2,1),(3,1)],[(2,0),(2,1),(2,2),(2,3)],[(0,2),(1,2),(2,2),(3,2)],[(1,0),(1,1),(1,2),(1,3)]],
    "O": [[(1,0),(2,0),(1,1),(2,1)]]*4,
    "T": [[(1,0),(0,1),(1,1),(2,1)],[(1,0),(1,1),(2,1),(1,2)],[(0,1),(1,1),(2,1),(1,2)],[(1,0),(0,1),(1,1),(1,2)]],
    "S": [[(1,0),(2,0),(0,1),(1,1)],[(1,0),(1,1),(2,1),(2,2)],[(1,1),(2,1),(0,2),(1,2)],[(0,0),(0,1),(1,1),(1,2)]],
    "Z": [[(0,0),(1,0),(1,1),(2,1)],[(2,0),(1,1),(2,1),(1,2)],[(0,1),(1,1),(1,2),(2,2)],[(1,0),(0,1),(1,1),(0,2)]],
    "J": [[(0,0),(0,1),(1,1),(2,1)],[(1,0),(2,0),(1,1),(1,2)],[(0,1),(1,1),(2,1),(2,2)],[(1,0),(1,1),(0,2),(1,2)]],
    "L": [[(2,0),(0,1),(1,1),(2,1)],[(1,0),(1,1),(1,2),(2,2)],[(0,1),(1,1),(2,1),(0,2)],[(0,0),(1,0),(1,1),(1,2)]]
}

class Piece:
    def __init__(self, kind):
        self.kind = kind
        self.rot = 0
        self.x = 3
        self.y = 0
    def cells(self):
        return [(self.x+dx, self.y+dy) for dx,dy in SHAPES[self.kind][self.rot]]
    def rotated(self, rot):
        return [(self.x+dx, self.y+dy) for dx,dy in SHAPES[self.kind][rot % 4]]

class Tetris:
    def __init__(self, root):
        self.root = root
        root.title("Tetris (A/D move, S drop, R rotate, Q quit)")
        self.cv = tk.Canvas(root, width=W, height=H, bg=BG, highlightthickness=0)
        self.cv.pack()
        self.board = [[None]*COLS for _ in range(ROWS)]
        self.score = 0
        self.interval = 500
        self.soft_interval = 40
        self.soft_drop = False
        self.running = True
        self.cur = self.new_piece()
        self.next = self.new_piece()
        root.bind("<KeyPress>", self.key_down)
        root.bind("<KeyRelease>", self.key_up)
        self.draw()
        self.tick()

    def new_piece(self):
        return Piece(random.choice(list(SHAPES.keys())))

    def valid(self, cells):
        for x,y in cells:
            if x < 0 or x >= COLS or y >= ROWS: return False
            if y >= 0 and self.board[y][x] is not None: return False
        return True

    def lock(self):
        for x,y in self.cur.cells():
            if y < 0:
                self.running = False
                self.game_over()
                return
            self.board[y][x] = self.cur.kind
        self.clear_lines()
        self.cur = self.next
        self.next = self.new_piece()
        if not self.valid(self.cur.cells()):
            self.running = False
            self.game_over()

    def clear_lines(self):
        new = [r for r in self.board if any(c is None for c in r)]
        cleared = ROWS - len(new)
        for _ in range(cleared):
            new.insert(0, [None]*COLS)
        self.board = new
        self.score += [0,40,100,300,1200][cleared]

    def move(self, dx, dy):
        if not self.running: return
        nx, ny = self.cur.x + dx, self.cur.y + dy
        cells = [(nx+dx2, ny+dy2) for dx2,dy2 in SHAPES[self.cur.kind][self.cur.rot]]
        if self.valid(cells):
            self.cur.x, self.cur.y = nx, ny
        elif dy == 1:
            self.lock()

    def rotate(self):
        nr = (self.cur.rot + 1) % 4
        cells = self.cur.rotated(nr)
        if self.valid(cells):
            self.cur.rot = nr
        else:
            for kick in (-1,1,-2,2):
                kc = [(x+kick,y) for x,y in cells]
                if self.valid(kc):
                    self.cur.x += kick
                    self.cur.rot = nr
                    break

    def draw_cell(self, x, y, color):
        x0, y0 = x*CELL, y*CELL
        self.cv.create_rectangle(x0,y0,x0+CELL,y0+CELL, fill=color, outline=GRID, width=1)

    def draw(self):
        self.cv.delete("all")
        for y in range(ROWS):
            for x in range(COLS):
                self.draw_cell(x,y, GRID if self.board[y][x] is None else COLORS[self.board[y][x]])
        for x,y in self.cur.cells():
            if y >= 0:
                self.draw_cell(x,y,COLORS[self.cur.kind])
        self.cv.create_text(5,5,anchor="nw",fill="#cbd5e1",font=("Consolas",12),text=f"Score: {self.score}")

    def tick(self):
        if not self.running: return
        self.move(0,1)
        self.draw()
        self.root.after(self.soft_interval if self.soft_drop else self.interval, self.tick)

    def key_down(self, e):
        k = e.keysym.lower()
        if k == "a": self.move(-1,0)
        elif k == "d": self.move(1,0)
        elif k == "s": self.soft_drop = True
        elif k == "r": self.rotate()
        elif k == "q": self.root.destroy()
        self.draw()

    def key_up(self, e):
        if e.keysym.lower() == "s":
            self.soft_drop = False

    def game_over(self):
        self.draw()
        self.cv.create_rectangle(0,H//2-40,W,H//2+40,fill="#000000",outline="")
        self.cv.create_text(W//2,H//2,fill="#ff5a5f",font=("Consolas",20,"bold"),text="GAME OVER\nPress Q to Quit")

if __name__ == "__main__":
    root = tk.Tk()
    Tetris(root)
    root.mainloop()
